<?php

declare(strict_types=1);

namespace Amasty\SecondModule\Model;

use Amasty\UserName\Model\ConfigProviderAbstract;

class ConfigProvider extends ConfigProviderAbstract
{
    protected $pathPrefix = 'amasty_second_module/';

    public function isUseMagentoCartController(): bool
    {
        return (bool)$this->getConfig('general/use_magento_cart');
    }

    public function getPromoSku(): string
    {
        return (string)$this->getConfig('general/promo_sku');
    }

    public function getForPromoSku(): array
    {
        return array_map('trim', explode(',', $this->getConfig('general/for_promo_sku')));
    }
}
