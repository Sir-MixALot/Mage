<?php

declare(strict_types=1);

namespace Amasty\SecondModule\Plugin\Checkout\Controller;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\RequestInterface;

class CartPlugin
{
    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    public function __construct(
        RequestInterface $request,
        ProductRepositoryInterface $productRepository
    ) {
        $this->request = $request;
        $this->productRepository = $productRepository;
    }

    public function beforeExecute()
    {
        if ($sku = (string)$this->request->getParam('sku')) {
            try {
                $product = $this->productRepository->get($sku);
                $requestParams = $this->request->getParams();
                $requestParams['product'] = $product->getId();
                $this->request->setParams($requestParams);
            } catch (\Exception $e) {
                null;
            }
        }
    }
}
