<?php

declare(strict_types=1);

namespace Amasty\SecondModule\Plugin\UserName\Block;

use Amasty\SecondModule\Model\ConfigProvider;
use Amasty\UserName\Block\Index;

class IndexPlugin
{
    const ADD_TO_CART_ROUTE = 'checkout/cart/add';

    /**
     * @var ConfigProvider
     */
    private $configProvider;

    public function __construct(
        ConfigProvider $configProvider
    ) {
        $this->configProvider = $configProvider;
    }

    public function aroundGetFormAction(Index $subject, \Closure $closure)
    {
        if ($this->configProvider->isUseMagentoCartController()) {
            return self::ADD_TO_CART_ROUTE;
        }

        return $closure();
    }
}
