<?php

declare(strict_types=1);

namespace Amasty\SecondModule\Observer;

use Amasty\SecondModule\Model\ConfigProvider;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class OnAmastyAddCartItem implements ObserverInterface
{
    /**
     * @var ConfigProvider
     */
    private $configProvider;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    public function __construct(
        ConfigProvider $configProvider,
        ProductRepositoryInterface $productRepository
    ) {
        $this->configProvider = $configProvider;
        $this->productRepository = $productRepository;
    }

    public function execute(Observer $observer)
    {
        /** @var ProductInterface $product */
        $product = $observer->getEvent()->getProduct();
        /** @var \Magento\Quote\Model\Quote $quote */
        $quote = $observer->getEvent()->getQuote();
        $forSkus = $this->configProvider->getForPromoSku();
        $promoSku = $this->configProvider->getPromoSku();

        if ($promoSku && in_array($product->getSku(), $forSkus)) {
            try {
                $product = $this->productRepository->get($promoSku);
                $quote->addProduct($product, 1);
                $quote->save();
            } catch (\Exception $e) {
                null;
            }
        }
    }
}
