<?php


namespace Amasty\UserName\Model;
use Magento\Framework\App\Config\ScopeConfigInterface;

abstract class ConfigProviderAbstract
{
    /**
     * @var ScopeConfigInterface
     */
    protected  $scopeConfig;

    protected $pathPrefix = 'f_config/';

    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
    }

    public function getConfig($path)
    {
        $val = $this->scopeConfig->getValue($this->pathPrefix . $path);
        return $val;
    }
}
