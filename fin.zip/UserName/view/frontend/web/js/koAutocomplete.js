define([
    'jquery',
    'underscore',
    'uiComponent'
], function($, _, Component) {
    'use strict'

    return Component.extend({
        defaults: {
            minLength: 3,
            searchUrl: '',
            searchResults: [],
            currentSearchRequest: null,
            searchInputSelector: '#sku-search-input'
        },

        initObservable: function() {
            this._super().observe(['searchResults']);
            return this;
        },

        initialize: function() {
            this._super();
            $.async(this.searchInputSelector, function () {
                $(this.searchInputSelector).on('keyup', _.debounce(this.handleAutocomplete.bind(this), 300));
            }.bind(this));
        },

        handleAutocomplete: function () {
            var searchSku = $(this.searchInputSelector).val();

            if (searchSku.length >= this.minLength) {
                if (this.currentSearchRequest) {
                    this.currentSearchRequest.abort();
                }

                this.currentSearchRequest = $.ajax({
                    url: this.searchUrl,
                    data: {sku: searchSku},
                    dataType: 'json',
                    success: function (response) {
                        this.searchResults(_.toArray(response));
                    }.bind(this),
                });
            } else {
                this.searchResults([]);
            }
        }
    });
});
