<?php

declare(strict_types=1);

namespace Amasty\UserName\Plugin\SecondModule\Observer;

use Amasty\SecondModule\Observer\OnAmastyAddCartItem;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;

class OnAmastyAddCartItemPlugin
{
    /**
     * @var RequestInterface
     */
    private $request;

    public function __construct(
        RequestInterface $request
    ) {
        $this->request = $request;
    }

    public function aroundExecute(OnAmastyAddCartItem $subject, \Closure $closure, Observer $observer)
    {
        if (!$this->request->isAjax()) {
            $closure($observer);
        }
    }
}
