<?php

namespace Amasty\UserName\Controller\Index;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product\Type;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Event\Manager;
use Magento\Framework\Exception\NoSuchEntityException;

class Form extends Action
{
    /**
     * @var CheckoutSession
     */
    private $checkoutSession;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var Manager
     */
    private $eventManager;

    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        ProductRepositoryInterface $productRepository
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->productRepository = $productRepository;
        $this->eventManager = $context->getEventManager();
        parent::__construct($context);
    }

    public function execute()
    {
        if (!$this->getRequest()->isPost()) {
            $this->messageManager->addWarningMessage('Wrong http method.');
        }

        $sku = (string)$this->getRequest()->getParam('sku');
        $qty = (int)$this->getRequest()->getParam('qty');

        if ($sku && $qty) {
            try {
                $product = $this->productRepository->get($sku);

                if ($product->getTypeId() === Type::TYPE_SIMPLE) {
                    $stockItem = $product->getExtensionAttributes()->getStockItem();

                    if ($stockItem->getQty() >= $qty) {
                        $quote = $this->checkoutSession->getQuote();
                        if (!$quote->getId()) {
                            $quote->save();
                        }

                        $quote->addProduct($product, $qty);
                        $quote->save();
                        $this->eventManager->dispatch('amasty_add_cart_item', [
                            'product' => $product,
                            'quote' => $quote
                        ]);
                        $this->messageManager->addSuccessMessage($product->getName() . ' added to cart!');
                    } else {
                        $this->messageManager->addWarningMessage('No such qty.');
                    }
                } else {
                    $this->messageManager->addWarningMessage('Product not simple.');
                }
            } catch (NoSuchEntityException $e) {
                $this->messageManager->addWarningMessage('Wrong SKU.');
            } catch (\Exception $e) {
                $this->messageManager->addWarningMessage('Something went wrong.');
            }
        } else {
            $this->messageManager->addWarningMessage('Provide valid SKU and QTY.');
        }

        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('testp');
    }
}
