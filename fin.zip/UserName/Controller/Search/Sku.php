<?php

declare(strict_types=1);

namespace Amasty\UserName\Controller\Search;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\ResourceModel\Product;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\ResultFactory;

class Sku implements ActionInterface
{
    /**
     * @var ResultFactory
     */
    private $resultFactory;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var Product\CollectionFactory
     */
    private $productCollectionFactory;

    public function __construct(
        ResultFactory $resultFactory,
        RequestInterface $request,
        Product\CollectionFactory $productCollectionFactory
    ) {
        $this->resultFactory = $resultFactory;
        $this->request = $request;
        $this->productCollectionFactory = $productCollectionFactory;
    }

    public function execute()
    {
        $result = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $sku = (string)$this->request->getParam('sku');

        if ($sku) {
            $productCollection = $this->productCollectionFactory->create();
            $productCollection->addAttributeToSelect('name');
            $productCollection->addFieldToFilter('sku', ['like' => "%$sku%"]);
            $productCollection->setPageSize(20);
            $result->setData(array_map(function (ProductInterface $product) {
                return [
                    'sku' => $product->getSku(),
                    'name' => $product->getName()
                ];
            }, $productCollection->getItems()));
        } else {
            $result->setData([]);
        }

        return $result;
    }
}
