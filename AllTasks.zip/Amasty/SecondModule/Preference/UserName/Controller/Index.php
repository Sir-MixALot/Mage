<?php

declare(strict_types=1);

namespace Amasty\SecondModule\Preference\UserName\Controller;

use Amasty\UserName\Controller\Index\Index as OriginalController;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Message\ManagerInterface;

class Index extends OriginalController
{
    /**
     * @var Session
     */
    private $session;

    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        CheckoutSession $checkoutSession,
        ProductRepositoryInterface $productRepository,
        ManagerInterface $messageManager,
        ProductCollectionFactory $productCollectionFactory,
        Session $session
    ) {
        parent::__construct(
            $context,
            $scopeConfig,
            $checkoutSession,
            $productRepository,
            $messageManager,
            $productCollectionFactory
        );
        $this->session = $session;
    }

    public function execute()
    {
        if ($this->session->isLoggedIn()) {
            return parent::execute();
        }

        return $this->resultFactory->create(ResultFactory::TYPE_FORWARD)->forward('noroute');
    }
}
