<?php

namespace Amasty\UserName\Ui\Component\Form;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Amasty\UserName\Model\ResourceModel\Blacklist\CollectionFactory;

class DataProvider extends AbstractDataProvider
{

    protected $loadedData;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if(!isset($this->loadedData)){
            $blacklistItems = $this->collection->getItems();

            foreach($blacklistItems as $item){
                $this->loadedData[$this->getId()] = $item->getData();
            }
        }

        return $this->loadedData;
    }
}
