<?php

namespace Amasty\UserName\Model;
use Amasty\UserName\Model\BlacklistFactory;
use Amasty\UserName\Model\ResourceModel\Blacklist as BlacklistResource;

class BlacklistRepository
{
    /**
     * @var BlacklistFactory
     */
    private $blacklistFactory;

    /**
     * @var BlacklistResource
     */
    private $blacklistResource;

    public function __construct(
        BlacklistFactory $blacklistFactory,
        BlacklistResource $blacklistResource
    ) {
        $this->blacklistFactory = $blacklistFactory;
        $this->blacklistResource = $blacklistResource;
    }

    public function getBySku($sku){
        $blacklist = $this->blacklistFactory->create();
        $this->blacklistResource->load($blacklist, $sku, 'sku');

        return $blacklist;
    }

}
