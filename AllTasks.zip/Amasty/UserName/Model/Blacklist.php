<?php

namespace Amasty\UserName\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * @method string getSku()
 * @method int getQty()
 */


class Blacklist extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(
            ResourceModel\Blacklist::class
        );
    }
}
