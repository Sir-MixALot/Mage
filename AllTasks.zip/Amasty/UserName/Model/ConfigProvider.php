<?php


namespace Amasty\UserName\Model;

class ConfigProvider extends ConfigProviderAbstract
{
    public function isModuleEnabled()
    {
        $this->getConfig('general/enabled');
        return true;

    }

    public function isGreetingText()
    {
        $GT = $this->getConfig('general/greeting_text');
        return $GT;
    }

    public function isQtyEnabled()
    {
        $QE = $this->getConfig('general/qty_enabled');
        return $QE;
    }

    public function isQty()
    {
        $qty =  $this->getConfig('general/qty_value');
        return $qty;
    }
}
