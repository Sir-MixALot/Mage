<?php

namespace Amasty\UserName\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
    const BLACKLIST_TABLE_NAME = 'amasty_blacklist';

    public function install(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $setup->endSetup();

        $table = $setup->getConnection()
            ->newTable($setup->getTable(self::BLACKLIST_TABLE_NAME))
            ->addColumn(
                'b_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Blacklist ID'
            )
            ->addColumn(
                'sku',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Product SKU'
            )
            ->addColumn(
                'qty',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false],
                'Product QTY'
            )
            ->setComment('Blacklist table');

        $setup->getConnection()->createTable($table);

        $setup->endSetup();
    }
}
