<?php

namespace Amasty\UserName\Controller\Adminhtml\Blacklist;

use Amasty\UserName\Model\BlacklistFactory;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Amasty\UserName\Model\ResourceModel\Blacklist as BlacklistResource;

class Save extends Action
{
    /**
     * @var BlacklistFactory
     */
    private $blacklistFactory;

    /**
     * @var BlacklistResource
     */
    private $blacklistResource;

    public function __construct(
        Context $context,
        BlacklistFactory $blacklistFactory,
        BlacklistResource $blacklistResource
    ) {
        $this->blacklistFactory = $blacklistFactory;
        $this->blacklistResource = $blacklistResource;
        parent::__construct($context);
    }

    public function execute() {
       if($data = $this->getRequest()->getParams()){
           $blacklistId = $this->getRequest()->getParam('b_id');
           try{
               $blacklist = $this->blacklistFactory->create();

                if($blacklistId){
                    $this->blacklistResource->load($blacklist, $blacklistId);
                }

                $blacklist->addData($data);
                $this->blacklistResource->save($blacklist);
                $this->messageManager->addSuccessMessage('Product save!');
           }catch (\Exception $exception){
               $this->messageManager->addExceptionMessage($exception, $exception->getMessage());
           }

           return $this->_redirect('*/*/index');
       }
    }
}
