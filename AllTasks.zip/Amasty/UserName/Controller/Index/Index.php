<?php

declare(strict_types=1);

namespace Amasty\UserName\Controller\Index;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Message\ManagerInterface;

class Index extends Action
{
    /**
     * @var  ScopeConfigInterface
     */

    protected $scopeConfig;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * @var ProductCollectionFactory
     */
    protected $productCollectionFactory;


    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        CheckoutSession $checkoutSession,
        ProductRepositoryInterface $productRepository,
        ManagerInterface $messageManager,
        ProductCollectionFactory $productCollectionFactory
    ){
        $this->scopeConfig = $scopeConfig;
        $this->checkoutSession = $checkoutSession;
        $this->productRepository = $productRepository;
        $this->messageManager = $messageManager;
        $this->productCollectionFactory = $productCollectionFactory;
        parent::__construct($context);
    }
    public function execute()
    {
        if ($this->scopeConfig->isSetFlag('f_config/general/enabled')) {
            $page = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
            $page->getConfig()->getTitle()->set(__('My page title'));

            return $page;
        } else {
          die('This little module is DIE((');
        }
    }
}
