<?php

namespace Amasty\UserName\Controller\Index;

use Amasty\UserName\Model\BlacklistRepository;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product\Type;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Event\Manager;
use Magento\Framework\Exception\NoSuchEntityException;

class Form extends Action
{
    /**
     * @var CheckoutSession
     */
    private $checkoutSession;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var Manager
     */
    private $eventManager;

    /**
     * @var BlacklistRepository
     */
    private $blacklistRepository;

    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        ProductRepositoryInterface $productRepository,
        BlacklistRepository $blacklistRepository
    ) {
        $this->blacklistRepository = $blacklistRepository;
        $this->checkoutSession = $checkoutSession;
        $this->productRepository = $productRepository;
        $this->eventManager = $context->getEventManager();
        parent::__construct($context);
    }

    public function execute()
    {
        if (!$this->getRequest()->isPost()) {
            $this->messageManager->addWarningMessage('Wrong http method.');
        }

        $sku = (string)$this->getRequest()->getParam('sku');
        $qty = (int)$this->getRequest()->getParam('qty');

        if ($sku && $qty) {
            try {
                $product = $this->productRepository->get($sku);

                if ($product->getTypeId() === Type::TYPE_SIMPLE) {
                    $stockItem = $product->getExtensionAttributes()->getStockItem();

                    if ($stockItem->getQty() >= $qty) {
                        $quote = $this->checkoutSession->getQuote();
                        if (!$quote->getId()) {
                            $quote->save();
                        }
                        $blacklist = $this->blacklistRepository->getBySku($sku);
                        $newQty = $blacklist->getQty();
                        if ($blacklist->getSku()) {
                            $cartSku = $this->getCartSku($sku);
                            if ($cartSku) {
                                $cartQty = $this->getCartQty($sku);
                                if ($newQty < ($cartQty + $qty)) {
                                    $this->setCartQty($sku, $newQty);
                                    $this->messageManager->addSuccessMessage('Product added but only ' . $newQty . ' qty. This product is in blacklist!');
                                } else {
                                    $this->addToCart($product, $qty);
                                    $this->messageManager->addSuccessMessage($product->getName() . ' added to cart!');
                                }
                            } else{
                                $this->addToCart($product, $qty);
                                $this->messageManager->addSuccessMessage($product->getName() . ' added to cart!');
                            }
                        } else {
                            $this->addToCart($product, $qty);
                            $this->messageManager->addSuccessMessage($product->getName() . ' added to cart!');
                        }
                    } else {
                        $this->messageManager->addWarningMessage('No such qty.');
                    }
                } else {
                    $this->messageManager->addWarningMessage('Product not simple.');
                }
            } catch (NoSuchEntityException $e) {
                $this->messageManager->addWarningMessage('Wrong SKU.');
            } catch (\Exception $e) {
                $this->messageManager->addWarningMessage('Something went wrong.');
            }
        } else {
            $this->messageManager->addWarningMessage('Provide valid SKU and QTY.');
        }

        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('testp');
    }

    public function getCartItems(){
        $objectManager = ObjectManager::getInstance();
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');

        return $cart->getQuote()->getAllItems();
    }

    public function getCartSku($sku){
        $items = $this->getCartItems();
        foreach($items as $item) {
            $cartSku = $item->getSku();
            if($cartSku === $sku){
                return $cartSku;
            }
        }
        return false;
    }


    public function getCartQty($sku){
        $items = $this->getCartItems();
        foreach($items as $item) {
            $cartSku = $item->getSku();
            if($cartSku === $sku){
                return $item->getQty();
            }
        }
        return false;
    }

    public function setCartQty($sku, $qty){
        $items = $this->getCartItems();
        foreach($items as $item) {
            $cartSku = $item->getSku();
            if($cartSku === $sku){
                $item->setQty($qty);
                $item->save();
            }
        }
    }

    public function addToCart($product, $qty){
        $quote = $this->checkoutSession->getQuote();
        $quote->addProduct($product, $qty);
        $quote->save();
        $this->eventManager->dispatch('amasty_add_cart_item', [
            'product' => $product,
            'quote' => $quote
        ]);
    }
}
