<?php

namespace Amasty\UserName\Block;

use Amasty\UserName\Model\ConfigProvider;
use Magento\Framework\View\Element\Template;

class Index extends Template
{
    const ADD_TO_CART_ROUTE = 'testp/index/form';

    /**
     * @var ConfigProvider
     */
    private $configProvider;

    public function __construct(
        Template\Context $context,
        ConfigProvider $configProvider,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->configProvider = $configProvider;
    }

    public function getModuleEnabled()
    {
         return $this->configProvider->isModuleEnabled();
    }

    public function getQtyEnabled()
    {
        return $this->configProvider->isQtyEnabled();
    }

    public function getGreetingText()
    {
        return $this->configProvider->isGreetingText();
    }

    public function getQty()
    {
        return $this->configProvider->isQty();
    }

    public function getFormAction()
    {
        return self::ADD_TO_CART_ROUTE;
    }
}

